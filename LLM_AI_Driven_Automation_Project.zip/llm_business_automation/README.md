# LLM-Powered Business Automation Assistant

Starter project for the EdQuest assignment **AI-Driven Automation with LLMs**.

## Features
- Three workflow templates: customer support reply, document summary, and action-item extraction.
- Prompt construction with instructions not to invent facts.
- Demo mode that runs without an API key.
- Integration point for a chosen model provider's official SDK.
- Human-review, privacy, and security guidance.

## Run
Requires Python 3.10+. Run `python app.py`. Demo mode does not call a live model.

## Enable live model calls
Implement `call_llm()` in `app.py` using your provider's current official SDK. Store credentials in an environment variable such as `LLM_API_KEY`; never commit secrets.

## Evaluation
Test output quality, extraction completeness, human correction rate, latency, cost, and privacy. Record actual results.

## Responsible use
Use least-privilege tool access, validate structured outputs, protect personal data, and require human approval for consequential actions. This is an educational prototype, not a production service.
